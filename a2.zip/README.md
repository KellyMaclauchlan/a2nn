# a2nn
assignment 2 comp 4107
